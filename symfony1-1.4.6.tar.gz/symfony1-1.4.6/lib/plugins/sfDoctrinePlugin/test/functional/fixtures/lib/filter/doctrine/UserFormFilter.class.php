<?php

/**
 * User filter form.
 *
 * @package    filters
 * @subpackage User *
 * @version    SVN: $Id: UserFormFilter.class.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class UserFormFilter extends BaseUserFormFilter
{
  public function configure()
  {
  }
}