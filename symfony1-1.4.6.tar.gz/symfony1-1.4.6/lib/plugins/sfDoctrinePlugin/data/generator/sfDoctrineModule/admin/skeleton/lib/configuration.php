<?php

/**
 * ##MODULE_NAME## module configuration.
 *
 * @package    ##PROJECT_NAME##
 * @subpackage ##MODULE_NAME##
 * @author     ##AUTHOR_NAME##
 * @version    SVN: $Id: configuration.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class ##MODULE_NAME##GeneratorConfiguration extends Base##UC_MODULE_NAME##GeneratorConfiguration
{
}
